#include<iostream>
#include<ctime>
#include<string.h>
#include"island.h"
using namespace std;
int GetInput()
{
	int choice;
	cin >> choice;
	return choice;
}

void DisplayMainMenu()
{
	cout << "This program simulates a change in the population of hares and wolves with she-wolves on an isolated island\n\n";
	cout << "Please make your selection\n";
	cout << "1 - View the results of the performed simulations\n";
	cout << "2 - Start new simulation\n";
	cout << "3 - Quit\n";
	cout << "Selection: ";
}

void DisplayOptionsMenu()
{
	cout << "Options Menu\n";
	cout << "Please make your selection\n";
	cout << "1 - Difficulty\n";
	cout << "2 - Sound\n";
	cout << "3 - Back\n";
	cout << "Selection: ";
}
int main()
{
	setlocale(LC_ALL, "");
	srand(time(0));
	const int sizeIsland = 20;
	int startSizeH = 0;
	int startSizeW = 0;
	int startSizeSW = 0;
	int sizeHare = 0;
	int sizeWolf = 0;
	int sizeSheWolf = 0;
	int lifeSpanH, lifeSpanW, maxWhunger;
	int* isl = nullptr;
	isl = new (int[pow(sizeIsland, 2)]);
	for (size_t i = 0; i < sizeIsland; i++)
		for (size_t j = 0; j < sizeIsland; j++)
			isl[i + j * sizeIsland] = 0;

	Hare* hares = nullptr;
	Wolf* wolves = nullptr;
	SheWolf* shewolves = nullptr;
	
	int choice = 0;
	do
	{
		system("cls");
		DisplayMainMenu();
		choice = GetInput();
		ifstream log_file("simulations.txt");
		switch (choice) {
		case 1:
			system("cls");
			cout << "Performed simulations:" << endl;
			if (log_file.is_open())
			{
				int reading; int w = 0;
				while (log_file >> reading)
				{
					w++;
					cout << w << ". Number of cycles: " << reading << ", hares: ";
					log_file >> reading;
					cout << reading << ", wolves: ";
					log_file >> reading;
					cout << reading << ", she-wolves: ";
					log_file >> reading;
					cout << reading << "." << endl;
				}
			}
			log_file.close();
			system("pause");
			break;
		case 2:
			system("cls");
			startIsland(sizeIsland, startSizeH, startSizeW, startSizeSW, lifeSpanH, lifeSpanW, maxWhunger);
			for (int i = 0; i < startSizeH; i++)
				addHare(hares, sizeHare, isl);

			for (int i = 0; i < startSizeW; i++)
				addWolf(wolves, sizeWolf, isl);

			for (int i = 0; i < startSizeSW; i++)
				addSheWolf(shewolves, sizeSheWolf, isl);
			evolution(wolves, shewolves, hares, sizeWolf, sizeSheWolf, sizeHare, isl, sizeIsland, lifeSpanH, lifeSpanW, maxWhunger);
			break;
		case 3:
			cout << "Goodbye!";
			break;

		default:
			break;
		}
	} while (choice == 1);

}