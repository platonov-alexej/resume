#include<iostream>
#include<iomanip>
#include<ctime>
#include<Windows.h>
#include<fstream>
using namespace std;

enum ConsoleColor
{
	Black = 0, Blue = 1, Green = 2, Cyan = 3, Red = 4, Magenta = 5, Brown = 6, LightGray = 7, DarkGray = 8,
	LightBlue = 9, LightGreen = 10, LightCyan = 11, LightRed = 12, LightMagenta = 13, Yellow = 14, White = 15
};

void SetColor(int text, int background)
{
	HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hStdOut, (WORD)((background << 4) | text));
}

void gotoxy(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

struct Hare
{
	int age, reproduction;
	short x, y;
};

struct Wolf
{
	int age, reproduction, hunger;
	short x, y;
};

struct SheWolf
{
	int age, reproduction, hunger;
	short x, y;
};

template<class T>
void addAnimal(T*& a, int& n, T b, int* pole, bool startCreat = 1, int x = 0, int y = 0) {
	b.age = 0;
	if (startCreat)
	{
		bool k = 1;
		do
		{
			b.x = rand() % 20;
			b.y = rand() % 20;
			if (pole[b.x + b.y * 20] == 0)
			{
				k = 0;
				pole[b.x + b.y * 20] = AnToDigit(a);
			}
		} while (k);
	}
	else
	{
		b.x = x;
		b.y = y;
		pole[b.x + b.y * 20] = AnToDigit(a);
	}
	T* p = new T[n + 1];
	for (int i = 0; i < n; i++)
		p[i] = a[i];
	p[n] = b;
	n++;
	delete[]a;
	a = p;
}

template<class T>
void delAnimal(T*& a, int& n, int pos, int* pole) {
	T* p = new(T[n - 1]);
	pole[a[pos].x + 20 * a[pos].y] = 0;
	for (size_t i = 0; i < pos; i++)
	{
		p[i] = a[i];
	}
	for (size_t i = pos; i < n - 1; i++)
	{
		p[i] = a[i + 1];
	}
	a = p;
	n--;
}
template<class T>
void moveAnimal(T*& a, int pos, int* pole)
{
	bool b = 1;
	pole[a[pos].x + a[pos].y * 20] = 0;
	int newX, newY;
	do
	{
		newX = a[pos].x + rand() % 3 - 1;
		newY = a[pos].y + rand() % 3 - 1;
		if (newX >= 0 && newY >= 0 && newX <= 19 && newY <= 19 && pole[newX + newY * 20] == 0)
		{
			b = 0;
			a[pos].x = newX;
			a[pos].y = newY;
			pole[a[pos].x + a[pos].y * 20] = AnToDigit(a);
		}
	} while (b);
}

void addHare(Hare*& p, int& size, int* pole, bool firstCreat = 1, int x = 0, int y = 0)
{
	Hare pt;
	pt.reproduction = 0;
	addAnimal(p, size, pt, pole, firstCreat, x, y);
}

void addWolf(Wolf*& p, int& size, int* pole, bool firstCreat = 1, int x = 0, int y = 0)
{
	Wolf pt;
	pt.hunger = 0;
	pt.reproduction = 0;
	addAnimal(p, size, pt, pole, firstCreat, x, y);
}

void addSheWolf(SheWolf*& p, int& size, int* pole, bool firstCreat = 1, int x = 0, int y = 0)
{
	SheWolf pt;
	pt.hunger = 0;
	pt.reproduction = 0;
	addAnimal(p, size, pt, pole, firstCreat, x, y);
}

void startIsland(int sizeIsland, int& startSizeH, int& startSizeW, int& startSizeSW, int& lifeSpanH, int& lifeSpanW, int& maxWhunger)
{
	cout << "  ";
	char c;
	for (size_t i = 0; i < sizeIsland; i++)
	{
		c = 65 + i;
		cout << setw(2) << c;
	}
	cout << endl << "   ";
	for (size_t i = 1; i <= sizeIsland; i++)
		cout << "--";
	cout << endl;
	for (size_t i = 0; i < sizeIsland; i++)
	{
		cout << setw(2) << i << "| " << setw(2 * sizeIsland - 1) << "|" << endl;
	}
	cout << "   ";
	for (size_t i = 1; i <= sizeIsland; i++)
		cout << "--";
	SetColor(15, 0);
	gotoxy(45, 2);
	cout << "Enter number of hares "; cin >> startSizeH;
	gotoxy(45, 3);
	cout << "Enter number of wolves "; cin >> startSizeW;
	gotoxy(45, 4);
	cout << "Enter number of she-wolves "; cin >> startSizeSW;
	gotoxy(45, 5);
	cout << "Enter life span hares "; cin >> lifeSpanH;
	gotoxy(45, 6);
	cout << "Enter life span wolves and she-wolves "; cin >> lifeSpanW;
	gotoxy(45, 7);
	cout << "Enter wolves level of maximum hunger "; cin >> maxWhunger;
	gotoxy(45, 10);
	cout << "Press 'Enter' to continue,";
	gotoxy(45, 11);
	cout << "enter 'q' to exit";
}

void showIsland(int* pole, int sizeIsland, int sw, int ssw, int sh, int* old_pole)
{
	for (int i = 0; i < sizeIsland; i++)
		for (int j = 0; j < sizeIsland; j++)
		{
			if (old_pole[i * sizeIsland + j] != 0)
			{
				gotoxy(2 * i + 3, j + 2);
				cout << " ";
			}
		}
	for (int i = 0; i < sizeIsland; i++)
		for (int j = 0; j < sizeIsland; j++)
			old_pole[i * sizeIsland + j] = pole[i * sizeIsland + j];

	char z;
	for (int i = 0; i < sizeIsland; i++)
		for (int j = 0; j < sizeIsland; j++)
		{
			if (pole[i * sizeIsland + j] != 0)
			{
				gotoxy(2 * i + 3, j + 2);
				switch (pole[i * sizeIsland + j])
				{
				case 111:
					SetColor(9, 0);
					break;
				case 64:
					SetColor(14, 0);
					break;
				case 38:
					SetColor(10, 0);
					break;
				}
				z = pole[i * sizeIsland + j];
				cout << z;
			}
		}
	gotoxy(3, 23);
	cout << "                                                                         ";
	SetColor(14, 0);
	gotoxy(3, 23);
	cout << "Wolves(@): " << sw;
	SetColor(10, 0); cout << "   She-Wolves(&): " << ssw;
	SetColor(9, 0); cout << "   Hares(o): " << sh << endl;
	SetColor(15, 0);
	gotoxy(3, 25);
}

template<class T>
int AnToDigit(T*& a)
{
	if (typeid(T) == typeid(Hare))
		return 111;
	else
		if (typeid(T) == typeid(Wolf))
			return 64;
		else
			if (typeid(T) == typeid(SheWolf))
				return 38;
}

template<class T>
void eatingHare(T*& a, int num_a, Hare*& h, int num_h, int& size_h, int* pole)
{
	a[num_a].hunger += 5;
	pole[a[num_a].x + a[num_a].y * 20] = 0;
	a[num_a].x = h[num_h].x;
	a[num_a].y = h[num_h].y;
	delAnimal(h, size_h, num_h, pole);
	pole[a[num_a].x + a[num_a].y * 20] = AnToDigit(a);
}

void breedingW(Wolf*& w, int num_w, int& size_w, SheWolf*& sw, int num_sw, int& size_sw, int* pole)
{
	sw[num_sw].reproduction = 0;
	pole[w[num_w].x + w[num_w].y * 20] = 0;
	w[num_w].x = sw[num_sw].x;
	w[num_w].y = sw[num_sw].y;
	if (rand() % 2)
		addWolf(w, size_w, pole, 0, w[num_w].x, w[num_w].y);
	else
		addSheWolf(sw, size_sw, pole, 0, w[num_w].x, w[num_w].y);
	/*pole[w[num_w].x + w[num_w].y * 20] = 4;*/
}

void breedingH(Hare*& h, int num_h, int& size_h, int* pole)
{
	h[num_h].reproduction = 0;
	addHare(h, size_h, pole, 0, h[num_h].x, h[num_h].y);
	/*pole[h[num_h].x + h[num_h].y * 20] = 5;*/
}

void evolution(Wolf *&wolves, SheWolf *&shewolves, Hare *&hares, int &sizeWolf, int &sizeSheWolf, int &sizeHare, int *isl, int sizeIsland, int& lifeSpanH, int& lifeSpanW, int& maxWhunger)
{
	int* old_isl = nullptr;
	old_isl = new (int[pow(sizeIsland, 2)]);
	for (size_t i = 0; i < sizeIsland; i++)
		for (size_t j = 0; j < sizeIsland; j++)
			old_isl[i + j * sizeIsland] = 0;
	char choise;
	int numCyc = 0;
	do
	{
		showIsland(isl, sizeIsland, sizeWolf, sizeSheWolf, sizeHare, old_isl);
		for (int i = 0; i < sizeWolf; i++)
		{
			if (wolves[i].age >= lifeSpanW || wolves[i].hunger >= maxWhunger)
				delAnimal(wolves, sizeWolf, i, isl);
			else
			{
				wolves[i].age++;
				wolves[i].hunger++;
				bool b = true;
				for (int j = 0; j < sizeHare; j++)
					if (abs(hares[j].x - wolves[i].x) <= 1 && abs(hares[j].y - wolves[i].y) <= 1)
					{
						eatingHare(wolves, i, hares, j, sizeHare, isl);
						b = false;
						j = sizeHare;
					}
				if (b && wolves[i].age >= 2)
					for (int j = 0; j < sizeSheWolf; j++)
						if (abs(shewolves[j].x - wolves[i].x) <= 1 && abs(shewolves[j].y - wolves[i].y) <= 1)
							if (shewolves[j].reproduction >= 5)
							{
								breedingW(wolves, i, sizeWolf, shewolves, j, sizeSheWolf, isl);
								b = false;
								j = sizeSheWolf;
							}
				if (b)
					moveAnimal(wolves, i, isl);
			}
		}
		for (int i = 0; i < sizeSheWolf; i++)
		{
			if (shewolves[i].age >= lifeSpanW || shewolves[i].hunger >= maxWhunger)
				delAnimal(shewolves, sizeSheWolf, i, isl);
			else
			{
				shewolves[i].age++;
				shewolves[i].hunger++;
				bool b = true;
				for (int j = 0; j < sizeHare; j++)
					if (abs(hares[j].x - shewolves[i].x) <= 1 && abs(hares[j].y - shewolves[i].y) <= 1)
					{
						eatingHare(shewolves, i, hares, j, sizeHare, isl);
						b = false;
						j = sizeHare;
					}
				if (b && shewolves[i].reproduction > 0)
					moveAnimal(shewolves, i, isl);
				shewolves[i].reproduction++;
			}
		}
		for (int i = 0; i < sizeHare; i++)
		{
			if (hares[i].age >= lifeSpanH)
				delAnimal(hares, sizeHare, i, isl);
			else
			{
				hares[i].age++;
				bool b = true;
				if (hares[i].reproduction >= 5)
				{
					breedingH(hares, i, sizeHare, isl);
					b = false;
				}
				if (b)
					moveAnimal(hares, i, isl);
				hares[i].reproduction++;
			}
		}
		numCyc++;
		gotoxy(45, 13);
		cout << "Selection: ";
		choise = getchar();
	} while (choise != 'q');
	ofstream log_file;
	log_file.open("simulations.txt", ios::app);
	if (log_file.is_open())
		log_file << numCyc << " " << sizeHare << " " << sizeWolf << " " << sizeSheWolf << endl;
	else
	{
		cout << "error";
		system("pause");
	}
	log_file.close();
}
